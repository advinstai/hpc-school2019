import os
myid = int( os.environ['OMPI_COMM_WORLD_RANK'] )
size = int( os.environ['OMPI_COMM_WORLD_RANK'] )

dirname="dir_py_" + str(myid)
os.mkdir(dirname)
file = open(dirname + "/testfile.txt","w") 

if( myid % 2 == 0):
    file.write("\nI am %d of %d processes execution and I am an even process\n" % ( myid, size ) );
else:
    file.write("\nI am %d of %d processes execution and I am an odd process\n" % ( myid, size ) );
