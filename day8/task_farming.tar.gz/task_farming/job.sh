#!/bin/bash
#SBATCH -N 2
#SBATCH --ntasks-per-node=8 
#SBATCH --time=00:30:00

module purge 
module load openmpi

mpirun ./exec_script_example.sh
mpirun python ./exec_script_example.py
